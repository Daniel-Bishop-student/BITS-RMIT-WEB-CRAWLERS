# Declarations
The following is a list of the declarations files located in this directory, with a quick summary of their purpose.

| Filename | Purpose |
|:---------|:--------|
| characters.rpy | Declarations for the characters. |
| images.rpy | Declarations for the various images in the novel. |
| other.rpy | Various types of declarations that don't fit in any of the other declarations files. |
