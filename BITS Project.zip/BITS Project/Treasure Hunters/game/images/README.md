# Images
The following is a list of the image files included. With information about their creator, and thus licensing.

## Backgrounds
| Name | Filename | Creator |
|:-----|:---------|:--------|

## Characters
| Name | Filename | Creator |
|:-----|:---------|:--------|

## Misc
| Filename | Purpose | Creator |
|:---------|:--------|:--------|
